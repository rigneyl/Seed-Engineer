
Writer Mechanics Suite · CSS Variants

Each file here is a drop-in replacement for your current base.css.
Try them by renaming one to `base.css` in your `shared` folder or updating your <link> href.

Styles included:
- style01-noir-gold.css      · Noir Gold (close to original)
- style02-ink-blue.css       · Ink Blue (cool, inky blues)
- style03-terminal-green.css · Terminal Green (mono, hacker-ish)
- style04-parchment.css      · Parchment (light, writerly)
- style05-neon-violet.css    · Neon Violet (bold, neon UI)
- style06-solar-dawn.css     · Solar Dawn (warm, orange glow)
- style07-fog-grey.css       · Fog Grey (subtle, neutral dark)
- style08-paper-minimal.css  · Paper Minimal (clean light mode)
- style09-sepia-night.css    · Sepia Night (warm noir pages)
- style10-cyber-grid.css     · Cyber Grid (retro-future grid)
